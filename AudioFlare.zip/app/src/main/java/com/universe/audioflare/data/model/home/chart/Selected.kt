package com.universe.audioflare.data.model.home.chart


import com.google.gson.annotations.SerializedName

data class Selected(
    @SerializedName("text")
    val text: String
)