package com.universe.audioflare.data.model.spotify


import com.google.gson.annotations.SerializedName

data class ExternalUrlsXXX(
    @SerializedName("spotify")
    val spotify: String?
)