package com.universe.audioflare.data.model.browse.artist


import com.google.gson.annotations.SerializedName

data class ChannelId(
    @SerializedName("id")
    val id: String
)